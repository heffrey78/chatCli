// Filename: prompt_handler.js

class PromptHandler {
  async handlePrompt(prompt, messages) {
    // Your existing handlePrompt logic goes here
  }
}

const iocContainer = require('./ioc_container');
iocContainer.register('promptHandler', () => new PromptHandler());
