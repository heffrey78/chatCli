// Filename: sys_info.js

const os = require('os');

const systemInfo = () => {
  const sysInfo = {
    system: os.type(),
    platform: os.platform(),
    arch: os.arch(),
    release: os.release(),
    shell: process.env.SHELL || 'unknown',
    isPowerShellInstalled: !!(
      process.env.PATHEXT &&
      process.env.PATHEXT.split(';').indexOf('.PS1') !== -1
    ),
  };

  console.table(sysInfo);
};

module.exports = systemInfo;
